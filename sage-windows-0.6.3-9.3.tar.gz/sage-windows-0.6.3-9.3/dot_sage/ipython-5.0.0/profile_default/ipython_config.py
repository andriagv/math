c.TerminalInteractiveShell.colors = 'Linux'
c.TerminalInteractiveShell.term_title = False
