SageMath for Windows
====================

Build files and instructions for the Cygwin-compatible build of Sage and
its executable installer and auxiliary files.

You can find the latest release (for now) at https://github.com/sagemath/sage-windows/releases

Occasionally new versions of SageMath for Windows are released independently
of the Sage version (e.g. to make improvements with the Windows installer
itself).  The changes between installer versions are listed in the
[changelog](CHANGES.md).

Instructions
============

This repository should be run from within Cygwin.

This Cygwin requires the 'wget' and 'python' packages.
